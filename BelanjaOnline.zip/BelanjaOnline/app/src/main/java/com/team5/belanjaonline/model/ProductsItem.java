package com.team5.belanjaonline.model;

public class ProductsItem{
	private String image;
	private String price;
	private Rating rating;
	private String description;
	private int id;
	private String title;
	private String category;

	public String getImage(){
		return image;
	}

	public String getPrice(){
		return price;
	}

	public Rating getRating(){
		return rating;
	}

	public String getDescription(){
		return description;
	}

	public int getId(){
		return id;
	}

	public String getTitle(){
		return title;
	}

	public String getCategory(){
		return category;
	}

	public String toString() {
		return "ProductsItem{" +
				"image='" + image + '\'' +
				", price=" + price +
				", rating=" + rating +
				", description='" + description + '\'' +
				", id=" + id +
				", title='" + title + '\'' +
				", category='" + category + '\'' +
				'}';
	}
}
