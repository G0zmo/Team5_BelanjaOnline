package com.team5.belanjaonline;

import com.team5.belanjaonline.model.ProductsItem;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface MyAPI {
    // Trailing slash is needed
    String BASE_URL = "https://fakestoreapi.com/";

    @GET("/products")
    Call<List<ProductsItem>> getProducts();

    @GET("/products/{id}")
    Call<ProductsItem> getProduct(@Path("id") String id);
}
