package com.team5.belanjaonline.database;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Product {
    @PrimaryKey(autoGenerate = true)
    public int pid;

    @ColumnInfo(name = "title")
    public String title;

    @ColumnInfo(name = "price")
    public String price;

    @ColumnInfo(name = "description")
    public String description;

    @ColumnInfo(name = "category")
    public String category;

    @ColumnInfo(name = "image")
    public String image;

    @ColumnInfo(name = "rating_rate")
    public String rating_rate;

    @ColumnInfo(name = "rating_count")
    public String rating_count;
}
