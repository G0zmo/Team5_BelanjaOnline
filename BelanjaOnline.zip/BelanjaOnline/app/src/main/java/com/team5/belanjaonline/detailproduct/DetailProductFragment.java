package com.team5.belanjaonline.detailproduct;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;

import com.squareup.picasso.Picasso;
import com.team5.belanjaonline.R;
import com.team5.belanjaonline.RetrofitInstance;
import com.team5.belanjaonline.database.Product;
import com.team5.belanjaonline.database.ProductViewModel;
import com.team5.belanjaonline.home.HomeFragment;
import com.team5.belanjaonline.home.ProductAdapter;
import com.team5.belanjaonline.model.ProductsItem;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailProductFragment extends Fragment {
    private ProductViewModel productViewModel;
    private static final String TAG_PID = "TAG_PID";
    private static final String TAG_TITLE = "TAG_TITLE";
    private static final String TAG_PRICE = "TAG_PRICE";
    private static final String TAG_DESCRIPTION = "TAG_DESCRIPTION";
    private static final String TAG_CATEGORY = "TAG_CATEGORY";
    private static final String TAG_IMAGE = "TAG_IMAGE";
    private static final String TAG_RATING_RATE = "TAG_RATING_RATE";
    private static final String TAG_RATING_COUNT = "TAG_RATING_COUNT";

    private int pid;
    private String title;
    private String price;
    private String description;
    private String category;
    private String image;
    private String rating_rate;
    private String rating_count;

    private TextView tvDetailTitle,tvDetailPrice,tvDetailCategory,tvDetailDescription;
    private ImageView ivDetailProduct;

    public static DetailProductFragment newInstance(Product product) {
        Bundle args = new Bundle();
        args.putInt(TAG_PID,product.pid);
        args.putString(TAG_TITLE, product.title);
        args.putString(TAG_PRICE, product.price);
        args.putString(TAG_DESCRIPTION, product.description);
        args.putString(TAG_CATEGORY, product.category);
        args.putString(TAG_IMAGE, product.image);
        args.putString(TAG_RATING_RATE, product.rating_rate);
        args.putString(TAG_RATING_COUNT, product.rating_count);
        DetailProductFragment dpf = new DetailProductFragment();
        dpf.setArguments(args);
        return dpf;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null && getArguments().containsKey(TAG_PID)
                && getArguments().containsKey(TAG_TITLE)){
            pid = getArguments().getInt(TAG_PID);
            title = getArguments().getString(TAG_TITLE);
            price = getArguments().getString(TAG_PRICE);
            description = getArguments().getString(TAG_DESCRIPTION);
            category = getArguments().getString(TAG_CATEGORY);
            image = getArguments().getString(TAG_IMAGE);
            rating_rate = getArguments().getString(TAG_RATING_RATE);
            rating_count = getArguments().getString(TAG_RATING_COUNT);
        }

        productViewModel = new ViewModelProvider(requireActivity()).get(ProductViewModel.class);
    }
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.detailproduct_fragment, container, false);
        ivDetailProduct = view.findViewById(R.id.ivDetailImage);
        tvDetailTitle = view.findViewById(R.id.tvDetailTitle);
        tvDetailPrice = view.findViewById(R.id.tvDetailPrice);
        tvDetailCategory = view.findViewById(R.id.tvDetailCategory);
        tvDetailDescription = view.findViewById(R.id.tvDetailDescription);
        return view;
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Picasso.get().load(image).into(ivDetailProduct);
        tvDetailTitle.setText(title);
        tvDetailPrice.setText("$ " + price);
        tvDetailCategory.setText(category);
        tvDetailDescription.setText(description);
    }
}
