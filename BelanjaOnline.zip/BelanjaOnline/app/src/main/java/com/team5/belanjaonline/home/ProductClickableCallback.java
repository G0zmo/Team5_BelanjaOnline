package com.team5.belanjaonline.home;

import android.view.View;

import com.team5.belanjaonline.database.Product;

public interface ProductClickableCallback {
    void onClick(View view, Product product);
}
