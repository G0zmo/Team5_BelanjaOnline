package com.team5.belanjaonline.home;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.team5.belanjaonline.R;
import com.team5.belanjaonline.RetrofitInstance;
import com.team5.belanjaonline.database.Product;
import com.team5.belanjaonline.database.ProductViewModel;
import com.team5.belanjaonline.model.ProductsItem;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {
    public static HomeFragment newInstance() {
        return new HomeFragment();
    }

    private ProductViewModel productViewModel;
    private RecyclerView recyclerView;
    private ProductAdapter productAdapter;
    private ProgressBar pb;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        productViewModel = new ViewModelProvider(requireActivity()).get(ProductViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_fragment, container, false);
        recyclerView = view.findViewById(R.id.roomRecyclerView);
        int numberColumn = 3;
        productAdapter = new ProductAdapter(productClickableCallback);
        recyclerView.setAdapter(productAdapter);
        //recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),numberColumn));
        return view;
    }
    private final ProductClickableCallback productClickableCallback = new ProductClickableCallback() {
        @Override
        public void onClick(View view, Product user) {
            //DialogFragment newFragment = DeleteUserDialogFragment.newInstance(user);
            //newFragment.show(getChildFragmentManager(), "DeleteUserDialogFragment");
        }
    };
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        RetrofitInstance retrofitInstance = new RetrofitInstance();
        retrofitInstance.getAPI().getProducts().enqueue(new Callback<List<ProductsItem>>() {
            @Override
            public void onResponse(Call<List<ProductsItem>> call, Response<List<ProductsItem>> response) {
                for (int i = 0; i < response.body().size(); i++) {
                    Product product = new Product();
                    //Log.e("Data","ID : " + response.body().get(i).getId() + "\n");

                    product.pid = response.body().get(i).getId();
                    product.title = response.body().get(i).getTitle();
                    product.price = response.body().get(i).getPrice();
                    product.description = response.body().get(i).getDescription();
                    product.category = response.body().get(i).getCategory();
                    product.image = response.body().get(i).getImage();
                    product.rating_rate = response.body().get(i).getRating().getRate();
                    product.rating_count = response.body().get(i).getRating().getCount();

                    productViewModel.insert(product);
                }
                Log.e("HomeActicity", response.body().get(0).toString());
            }

            @Override
            public void onFailure(Call<List<ProductsItem>> call, Throwable t) {
                Log.e("HomeActivity", "Gagal koneksi ke API");
            }
        });
        productViewModel.getAllProducts().observe(getViewLifecycleOwner(), products -> {
            if (products != null) {
                productAdapter.submitList(products);
            }
        });
    }
}
