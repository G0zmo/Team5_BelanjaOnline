package com.team5.belanjaonline.login;

import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public final class LoginInstance {
    private static LoginInstance instance;

    private LoginAPI API;

    public static LoginInstance getInstance(){
        if(instance == null){
            instance = new LoginInstance();
        }
        return instance;
    }

    public LoginInstance(){
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(interceptor).build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(LoginAPI.BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        API = retrofit.create(LoginAPI.class);
    }

    public LoginAPI getAPI(){
        return API;
    }
}
