package com.team5.belanjaonline.home;

import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.room.DatabaseConfiguration;
import androidx.room.InvalidationTracker;
import androidx.room.Room;
import androidx.sqlite.db.SupportSQLiteOpenHelper;

import com.team5.belanjaonline.BaseActivity;
import com.team5.belanjaonline.R;
import com.team5.belanjaonline.RetrofitInstance;
import com.team5.belanjaonline.database.AppDatabase;
import com.team5.belanjaonline.database.Product;
import com.team5.belanjaonline.database.ProductDao;
import com.team5.belanjaonline.database.ProductViewModel;
import com.team5.belanjaonline.model.ProductsItem;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeActivity extends BaseActivity {

    private ProductViewModel productViewModel;
    private Product product;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container_all, HomeFragment.newInstance())
                    .commitNow();
        }
    }
}
