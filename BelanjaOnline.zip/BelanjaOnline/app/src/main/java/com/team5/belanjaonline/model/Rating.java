package com.team5.belanjaonline.model;

public class Rating{
	private String rate;
	private String count;

	public String getRate(){
		return rate;
	}

	public String getCount(){
		return count;
	}
}
