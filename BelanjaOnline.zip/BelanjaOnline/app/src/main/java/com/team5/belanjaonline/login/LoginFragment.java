package com.team5.belanjaonline.login;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import com.google.android.material.textfield.TextInputLayout;
import com.team5.belanjaonline.MainActivity;
import com.team5.belanjaonline.R;
import com.team5.belanjaonline.home.HomeActivity;
import com.team5.belanjaonline.sessionmanagement.SessionManagerUtil;

import java.util.Base64;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginFragment extends Fragment {
    private View rootView;
    private EditText tilUsername;
    private EditText tilPassword;
    private Button btnLogin;
    private ProgressBar pb;

    private String username;
    private String password;

    private LoginInstance loginInstance;

    private Executor backgroundThread = Executors.newSingleThreadExecutor();
    private Executor mainThread = new Executor() {
        private Handler mainThreadHandler = new Handler(Looper.getMainLooper());
        @Override
        public void execute(Runnable command) {
            mainThreadHandler.post(command);
        }
    };

    public static LoginFragment newInstance() {
        return new LoginFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.login_fragment, container, false);

        loginInstance = loginInstance.getInstance();

        pb = rootView.findViewById(R.id.progressBar);
        tilUsername = rootView.findViewById(R.id.etUsername);
        tilPassword = rootView.findViewById(R.id.etPassword);

        btnLogin = rootView.findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate();
            }
        });

        return rootView;
    }

    private void validate(){

        username = tilUsername.getText().toString();
        password = tilPassword.getText().toString();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(getActivity(), "Username dan password tidak boleh kosong!!", Toast.LENGTH_SHORT).show();
            return;
        }else{
            login(username,password);
            Log.e("Username and Password", "username : " + username + ", password : " + password);
        }
    }

    private void login(String username,String password){
        pb.setVisibility(View.VISIBLE);
        backgroundThread.execute(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                // connect server
                SystemClock.sleep(3000);
                mainThread.execute(new Runnable() {
                    @Override
                    public void run() {
                        loginInstance.getAPI().createPost(username,password).enqueue(new Callback<LoginData>() {
                            @Override
                            public void onResponse(Call<LoginData> call, Response<LoginData> response) {
                                if(response.message().equalsIgnoreCase("OK")){
                                    startAndStoreSession();
                                    startHomeActivity();
                                }else{
                                    Toast.makeText(getActivity(),"Username atau Password salah!!!",Toast.LENGTH_SHORT).show();
                                }
                                Log.e("Login onResponse","response : " + response.message());
                            }

                            @Override
                            public void onFailure(Call<LoginData> call, Throwable t) {
                                Log.e("Login onFailure",t.getMessage());
                            }
                        });
                        pb.setVisibility(View.INVISIBLE);
                    }
                });
            }
        });
    }

    private String generateToken(String username, String password){
        String feeds = username+":"+password;
        String token = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            token = Base64.getEncoder().encodeToString(feeds.getBytes());
        } else {
            token = feeds;
        }
        return token;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void startAndStoreSession(){
        SessionManagerUtil.getInstance()
                .storeUserToken(requireActivity(), generateToken(username, password));
        SessionManagerUtil.getInstance()
                .startUserSession(requireActivity(), 30);
    }

    private void startHomeActivity(){
        Intent intent = new Intent(requireActivity(), HomeActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        requireActivity().startActivity(intent);
    }
}
