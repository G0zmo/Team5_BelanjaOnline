package com.team5.belanjaonline.model;

import java.util.List;

public class Products{
	private List<ProductsItem> products;

	public List<ProductsItem> getProducts(){
		return products;
	}
}